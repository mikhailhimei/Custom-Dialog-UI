import React from "react";
import ReactDOM from "react-dom/client";
import ScenarioPage from "./page/ScenarioPage";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ScenarioPage />
  </React.StrictMode>
);