import React from "react";
import ReactDOM from "react-dom/client";

import { ScriptsPage } from "./src/page/ScriptsPage";
import { DialogProvider } from "./src/context/DialogProvider";

ReactDOM.createRoot(
  document.getElementById("root")!
).render(
  <React.StrictMode>
    <DialogProvider>
      <ScriptsPage />
    </DialogProvider>
  </React.StrictMode>
);