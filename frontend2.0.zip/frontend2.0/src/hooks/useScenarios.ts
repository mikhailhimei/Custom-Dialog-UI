import React, { useEffect, useState } from "react";
import { useDialogApi } from "../context/DialogContext";

export function useScenarios() {
  const api = useDialogApi();

  const [loading, setLoading] = useState(true);

  const [scriptsAction, setScriptAction] = useState<any[]>(
    []
  );

  // useEffect(() => {
  //   api
  //     .getScriptsAction()
  //     .then(setScriptAction)
  //     .finally(() => setLoading(false));
  // }, []);

  const getScriptsAction = async () => {
    setLoading(true);
    try {
      const data = await api.getScriptsAction();
      setScriptAction(data);
    }
    finally {
      setLoading(false);
    }
  };

  const deleteScenario = async (id: string) => {
    console.log("Deleting scenario with id:", id);
    await api.deleteScriptAction(id);
  };

    return {
    loading,
    getScriptsAction,
    deleteScenario,
  };
}