export interface HassLike {
  connection: {
    sendMessagePromise<T>(msg: any): Promise<T>;
  };
  states: Record<string, any>;
}

export class DialogApi {
  constructor(private hass: HassLike) {}

  async getScenarios() {
    console.log("WS => dialog/get_scenarios");

    const result =
      await this.hass.connection.sendMessagePromise({
        type: "dialog/get_scenarios",
      });

    console.log("WS <=", result);

    return result.scenarios;
}

  async saveScenarios(scenarios: any[]) {
    return this.hass.connection.sendMessagePromise({
      type: "dialog/save_scenarios",
      scenarios,
    });
  }

  async getLogs() {
    const result = await this.hass.connection.sendMessagePromise<{
      logs: any[];
    }>({
      type: "dialog/get_logs",
    });

    return result.logs;
  }

  getScripts() {
    return Object.values(this.hass.states)
      .filter(
        (entity: any) =>
          entity.entity_id.startsWith("script.")
      )
      .map((entity: any) => ({
        entity_id: entity.entity_id,
        name:
          entity.attributes?.friendly_name ??
          entity.entity_id,
      }));
  }

  async runScript(entityId: string) {
    return this.hass.connection.sendMessagePromise({
      type: "call_service",
      domain: "script",
      service: "turn_on",
      service_data: {
        entity_id: entityId,
      },
    });
  }
}