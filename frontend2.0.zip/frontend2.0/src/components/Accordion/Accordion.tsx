import React, { ReactNode, useState } from 'react';

interface Props {
  title: string;
  defaultOpen?: boolean;
  children: ReactNode;
}

export const Accordion = ({
  title,
  defaultOpen = false,
  children,
}: Props) => {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="accordion">
      <button onClick={() => setOpen((prev) => !prev)}>
        {title}
      </button>

      {open && (
        <div className="accordion-content">
          {children}
        </div>
      )}
    </div>
  );
};