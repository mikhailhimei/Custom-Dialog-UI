import React, { ReactNode } from 'react';

interface TabItem {
  key: string;
  label: string;
}

interface Props {
  items: TabItem[];
  active: string;
  onChange: (key: string) => void;
}

export const Tabs = ({ items, active, onChange }: Props) => {
  return (
    <div className="tabs">
      {items.map((item) => (
        <button
          key={item.key}
          className={active === item.key ? 'active' : ''}
          onClick={() => onChange(item.key)}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
};