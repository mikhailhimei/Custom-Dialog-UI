import React, { useState } from 'react';

import { Tabs } from '../components/Tabs/Tabs';
import { Modal } from '../components/Modal/Modal';
import { Pagination } from '../components/Pagination/Pagination';
import { ScriptForm } from '../components/ScriptForm/ScriptForm';

import {
  ScriptAction,
  ScriptActionDetails,
} from '../types/scripts';

import { useScenarios } from '../hooks/useScenarios';

export const ScriptsPage = () => {
  const [activeTab, setActiveTab] =
    useState('scripts');

  const [selectedScript, setSelectedScript] =
    useState<ScriptActionDetails>();

  const [modalOpen, setModalOpen] =
    useState(false);

  const [isEdit, setIsEdit] =
    useState(false);

  const {
    loading,
    getScriptsAction,
  } = useScenarios();

  const openCreateModal = () => {
    setSelectedScript(undefined);

    setIsEdit(false);

    setModalOpen(true);
  };

  const openEditModal = async (
    script: ScriptAction
  ) => {
    setIsEdit(true);

    // const data = await getScenario(
    //   script.uuid
    // );

    const data = []

    setSelectedScript(data);

    setModalOpen(true);
  };

  return (
    <div>
      <Tabs
        active={activeTab}
        onChange={setActiveTab}
        items={[
          {
            key: 'scripts',
            label: 'Сценарии',
          },
          {
            key: 'locations',
            label: 'Локи',
          },
        ]}
      />

      {activeTab === 'scripts' && (
        <>
          <h1>Сценарии</h1>

          <p>
            Управление сценариями и условиями
          </p>

          <button onClick={openCreateModal}>
            Добавить
          </button>

          {loading && (
            <div>Загрузка...</div>
          )}

          <div>
            {scripts?.script_actions.map((script) => (
              <button
                key={script.uuid}
                onClick={() =>
                  openEditModal(script)
                }
              >
                {script.title}
              </button>
            ))}
          </div>

          <Pagination
            page={scripts?.page || 1}
            totalPages={scripts?.total_pages || 1}
            onChange={(page) => {
              console.log(page);
            }}
          />
        </>
      )}

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
      >
        <ScriptForm
          initialData={selectedScript}
          isEdit={isEdit}
          onSave={(data) => {
            console.log(data);
          }}
          onDelete={async () => {
            if (!selectedScript?.uuid) return;

            await deleteScenario(
              selectedScript.uuid
            );

            setModalOpen(false);
          }}
        />
      </Modal>
    </div>
  );
};