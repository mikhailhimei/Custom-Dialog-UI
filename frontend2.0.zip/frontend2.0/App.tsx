import React from "react";
import ScriptsPage from "./src/page/ScriptsPage";

function App() {
  return <ScriptsPage />;
}

export default App;