import React, { ReactNode } from 'react';

interface Props {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
}

export const Modal = ({ open, onClose, children }: Props) => {
  if (!open) return null;

  return (
    <div className="modal-overlay">
      <div className="modal">
        <button onClick={onClose}>✕</button>

        {children}
      </div>
    </div>
  );
};