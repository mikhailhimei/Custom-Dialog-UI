import React from "react";
import ReactDOM from "react-dom/client";

import { AppRoot } from "./app/AppRoot";
import type { HassLike } from "./api/dialog-api";

import cssText from "./styles/globals.scss?inline";

const ELEMENT_NAME = "dialog-custom-ui-panel";

class DialogCustomUiPanel extends HTMLElement {
  private root?: ReactDOM.Root;
  private hassValue?: HassLike | null;

  set hass(hass: HassLike | null | undefined) {
    this.hassValue = hass;
    this.render();
  }

  get hass() {
    return this.hassValue;
  }

  connectedCallback() {
    this.injectStyles();
    this.render();
  }

  disconnectedCallback() {
    this.root?.unmount();
    this.root = undefined;
  }

  /**
   * 🔥 ВАЖНО: теперь мы НЕ используем <link>
   */
  private injectStyles() {
    const STYLE_ID = "dialog-custom-ui-style";

    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;

    style.textContent = `
      ${cssText}

      /* === HA SHADOW DOM OVERRIDES === */
      ha-dialog::part(content),
      ha-dialog::part(container) {
        background: #151518 !important;
        color: #f3f4f6 !important;
      }

      ha-dialog {
        --mdc-theme-surface: #151518;
        --ha-card-background: #151518;
      }
    `;

    document.head.appendChild(style);
  }

  private render() {
    if (!this.isConnected) return;

    if (!this.root) {
      this.root = ReactDOM.createRoot(this);
    }

    this.root.render(
      <React.StrictMode>
        <AppRoot hass={this.hassValue} />
      </React.StrictMode>
    );
  }
}

if (!customElements.get(ELEMENT_NAME)) {
  customElements.define(ELEMENT_NAME, DialogCustomUiPanel);
}